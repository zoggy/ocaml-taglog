# ocaml-taglog
Logging facilities using tags and levels
